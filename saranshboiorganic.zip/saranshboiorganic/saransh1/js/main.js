
// button option///
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

function filterFunction() {
  const input = document.getElementById("myInput");
  const filter = input.value.toUpperCase();
  const div = document.getElementById("myDropdown");
  const a = div.getElementsByTagName("a");
  for (let i = 0; i < a.length; i++) {
    txtValue = a[i].textContent || a[i].innerText;
    if (txtValue.toUpperCase().indexOf(filter) > -1) {
      a[i].style.display = "";
    } else {
      a[i].style.display = "none";
    }
  }
}


// slick slider///
$('.responsive').slick({
  dots: true,
  infinite: false,
  speed: 300,
  slidesToShow: 4,
  slidesToScroll: 4,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: true
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
});



// slider image///




// testminal///

$('.testimonal-slider').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplay: true,
  autoplaySpeed: 2000,
});


	

// counter//

const counters = document.querySelectorAll('.counter');

counters.forEach(counter => {
    const target = parseInt(counter.getAttribute('data-target'));
    const increment = Math.ceil(target / 100);
    let count = 0;

    const updateCounter = () => {
        count += increment;
        counter.textContent = count;

        if (count < target) {
            requestAnimationFrame(updateCounter);
            counter.classList.add('animate');
        } else {
            counter.classList.remove('animate');
        }
    };

    requestAnimationFrame(updateCounter);
});


// scanner///
function scanCode() {
  const code = document.getElementById('product-code').value;
  const resultDiv = document.getElementById('result');

  if (code === '123456') {
      resultDiv.innerHTML = '<p style="color: green;">This product is authentic and certified organic.</p>';
  } else {
      resultDiv.innerHTML = '<p style="color: red;">Invalid code. Please check and try again.</p>';
  }}
  
  
//   our product//

 function showMoreDetails() {
    document.getElementById('more-details').style.display = 'block';
  }
  
  function hideMoreDetails() {
    document.getElementById('more-details').style.display = 'none';
  }


  // menu//
  /* =========== Toggle Menu ============ */
  function toggleMenu() {
    const menu = document.querySelector('nav ul');
    menu.classList.toggle('show');
}


// card slider//

const next=document.querySelector('#next')
const prev=document.querySelector('#prev')

function handleScrollNext (direction) {
  const cards = document.querySelector('.card-content')
  cards.scrollLeft=cards.scrollLeft += window.innerWidth / 2 > 600 ? window.innerWidth /2 : window.innerWidth -100
}

function handleScrollPrev (direction) {
  const cards = document.querySelector('.card-content')
  cards.scrollLeft=cards.scrollLeft -= window.innerWidth / 2 > 600 ? window.innerWidth /2 : window.innerWidth -100
}

next.addEventListener('click', handleScrollNext)
prev.addEventListener('click', handleScrollPrev)